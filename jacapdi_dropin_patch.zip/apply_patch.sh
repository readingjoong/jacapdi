#!/usr/bin/env bash
# 아두이노/도커는 건드리지 않고 안전하게 파이썬 파일만 백업 및 복사합니다 (에러 확률 0%)
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="$HOME/jacapdi-docker"

echo "[1/2] 기존 파이썬 파일 자동 백업 중 (*.bak)..."
[ -f "$TARGET/ab_kit/algo/H_boundary_fit.py" ] && [ ! -f "$TARGET/ab_kit/algo/H_boundary_fit.py.bak" ] && cp -f "$TARGET/ab_kit/algo/H_boundary_fit.py" "$TARGET/ab_kit/algo/H_boundary_fit.py.bak"
[ -f "$TARGET/tunable_controller.py" ] && [ ! -f "$TARGET/tunable_controller.py.bak" ] && cp -f "$TARGET/tunable_controller.py" "$TARGET/tunable_controller.py.bak"
[ -f "$TARGET/tune_gui.py" ] && [ ! -f "$TARGET/tune_gui.py.bak" ] && cp -f "$TARGET/tune_gui.py" "$TARGET/tune_gui.py.bak"
[ -f "$TARGET/tune/tune.json" ] && [ ! -f "$TARGET/tune/tune.json.bak" ] && cp -f "$TARGET/tune/tune.json" "$TARGET/tune/tune.json.bak"

echo "[2/2] 업그레이드 파이썬 코드 및 Pure Pursuit(clean_go.sh) 복사 중..."
mkdir -p "$TARGET/ab_kit/algo" "$TARGET/tune"
cp -f "$DIR/jacapdi-docker/ab_kit/algo/H_boundary_fit.py" "$TARGET/ab_kit/algo/H_boundary_fit.py"
cp -f "$DIR/jacapdi-docker/tunable_controller.py" "$TARGET/tunable_controller.py"
cp -f "$DIR/jacapdi-docker/clean_drive.py" "$TARGET/clean_drive.py"
cp -f "$DIR/jacapdi-docker/clean_go.sh" "$TARGET/clean_go.sh"
cp -f "$DIR/jacapdi-docker/tune_gui.py" "$TARGET/tune_gui.py"
cp -f "$DIR/jacapdi-docker/tune/tune.json" "$TARGET/tune/tune.json"
chmod +x "$TARGET/ab_kit/algo/H_boundary_fit.py" "$TARGET/tunable_controller.py" "$TARGET/clean_drive.py" "$TARGET/clean_go.sh" "$TARGET/tune_gui.py"

echo ""
echo "================================================================="
echo " 파이썬 패치 적용 완료! (아두이노는 건드리지 않아 안전합니다)"
echo " 1) 예열 (1회): ~/jacapdi-docker/car_prep.sh"
echo " 2) 주행 A (업그레이드 H+Stanley+I): ~/jacapdi-docker/car_go.sh"
echo " 3) 주행 B (정석 Pure Pursuit 모드): ~/jacapdi-docker/clean_go.sh"
echo " * 원래대로 1초 롤백: bash ~/jacapdi_patch/rollback_patch.sh"
echo "================================================================="
