#!/usr/bin/env python3
"""실시간 파라미터 핫리로드 주행 제어기 (업그레이드 드롭인 교체본).

기존 tunable_controller.py 와 실행 인자, 토픽, JSON 설정 포맷이 100% 호환되면서
다음 4가지 핵심 문제를 해결함:
1. 무지연 즉시 발행: /lane_trajectory 수신 즉시(0ms) 조향 명령을 발행해 최대 50ms 타이머 대기 딜레이 제거
2. 독소 패치(off_tracking) 제거: 좌커브에서 차를 바깥쪽 실선으로 밀어내던 잘못된 식을 제거하고,
   정상적인 코너 안쪽 바이어스(inside_bias_m)와 차선 가드(lane_guard_m) 복원
3. 조향 I(적분) 제어기 + 스마트 안티와인드업 내장:
   카메라 사각지대(0~0.84m)와 지속 코너에서 부족했던 조향각을 적분항(i_gain)이 채워주어
   좌회전 끝(-100)까지 확실히 밀어주고, 오차 부호가 바뀌는 S자 변곡점에서는 적분값을 즉시 감쇠해 오버슈트 방지
"""
import json
import math
import os
import time
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from interfaces_pkg.msg import LaneTrajectory, MotionCommand

TUNE_FILE_DEFAULT = "/work/tune/tune.json"

DEFAULTS = {
    "stanley_gain": 1.15,          # 횡오차 비례 게인 (P)
    "heading_gain": 0.25,          # 차선 기울기 게인
    "curvature_gain": 0.45,        # 곡률 피드포워드 게인
    "i_gain": 1.20,                # 조향 적분 게인 (I: 지속 코너에서 최대 조향까지 밀어줌)
    "i_max_deg": 12.0,             # 적분항 최대 각도 제한 (안티와인드업, 도)
    "vehicle_speed_mps": 0.5,
    "softening_speed_mps": 0.1,
    "front_axle_offset_m": 0.1,
    "max_steer_deg": 25.0,
    "max_steering_step": 100,      # 1010f 펌웨어 기준 ±100 (구형 펌웨어면 YAML/JSON에서 7로 덮어씀)
    "steering_sign": -1.0,
    "steer_trim": 0.0,
    "path_offset_m": 0.04,         # 기본 왼쪽(안쪽) 여유 오프셋 (m)
    "inside_bias_m": 0.05,         # 좌커브 시 안쪽(왼쪽)으로 추가 붙기 (m)
    "inside_bias_right_m": 0.02,   # 우커브 시 안쪽(오른쪽)으로 추가 붙기 (m)
    "steer_rate": 0.0,             # 조향 변화율 제한 (0 = 제한 없음, 즉시 반응)
    "motor_balance": 2,            # 좌우 뒷바퀴 모터 밸런스 보정
    "stall_boost_pwm": 255,
    "lane_guard_m": 0.12,          # 차폭 55cm(49+3*2), 차선 85cm → 좌우 여유 15cm이므로 12cm 벗어나면 즉시 가드 발동!
    "lane_guard_left_m": 0.14,     # 좌측 점선 접근 경계 (14cm)
    "lane_guard_push": 25,         # 가드 발동 시 추가 조향량 (100단계 기준 25%, 7단계면 자동 스케일링)
    "lane_timeout_sec": 0.6,
    "pwm_by_step": [255, 255, 255, 255, 255, 255, 255, 255],
}


class TunableController(Node):
    def __init__(self):
        super().__init__("tunable_controller")
        qos_rel = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            durability=DurabilityPolicy.VOLATILE,
            depth=1,
        )

        # YAML 및 start_ab.sh 호환 파라미터 선언
        self.declare_parameter("left_speed_command", 255)
        self.declare_parameter("right_speed_command", 255)
        self.declare_parameter("max_steering_step", 100)
        self.declare_parameter("steering_sign", -1.0)
        self.declare_parameter("stanley_gain", 1.15)
        self.declare_parameter("heading_gain", 0.25)
        self.declare_parameter("vehicle_speed_mps", 0.5)
        self.declare_parameter("curvature_gain", 0.45)
        self.declare_parameter("i_gain", 1.20)
        self.declare_parameter("i_max_deg", 12.0)
        self.declare_parameter("softening_speed_mps", 0.1)
        self.declare_parameter("front_axle_offset_m", 0.1)
        self.declare_parameter("max_steer_deg", 25.0)
        self.declare_parameter("lane_timeout_sec", 0.6)
        self.declare_parameter("tune_file", TUNE_FILE_DEFAULT)

        self.params = dict(DEFAULTS)
        for k in list(DEFAULTS.keys()):
            if self.has_parameter(k):
                self.params[k] = self.get_parameter(k).value
        base_pwm = int(self.get_parameter("left_speed_command").value)
        self.params["pwm_by_step"] = [base_pwm] * 8

        self.tune_file = str(self.get_parameter("tune_file").value)
        self.tune_mtime = 0.0
        self._last_tune_check = 0.0
        self._ensure_tune_file()
        self._reload_tune(force=True)

        self.latest_traj = None
        self.last_rx = None
        self.last_ctrl_time = None
        self.prev_steer = 0.0
        self._err_int = 0.0          # 조향 적분(I) 누적 상태
        self.moving_since = None
        self.boost_until = 0.0

        self.create_subscription(LaneTrajectory, "/lane_trajectory", self.on_traj, qos_rel)
        self.pub = self.create_publisher(MotionCommand, "/topic_control_signal", qos_rel)
        # 타이머는 타임아웃 감시 및 JSON 리로드 보조용으로만 동작 (실제 제어는 on_traj에서 즉시 발행)
        self.create_timer(0.05, self.tick)

    def _ensure_tune_file(self):
        try:
            d = os.path.dirname(self.tune_file)
            if d:
                os.makedirs(d, exist_ok=True)
            if not os.path.exists(self.tune_file):
                with open(self.tune_file, "w", encoding="utf-8") as f:
                    json.dump(self.params, f, indent=1)
        except Exception as e:
            self.get_logger().warn(f"tune file init failed: {e}")

    def _reload_tune(self, force: bool = False):
        now = time.monotonic()
        if not force and (now - self._last_tune_check) < 0.25:
            return
        self._last_tune_check = now
        try:
            st = os.stat(self.tune_file)
            if not force and st.st_mtime <= self.tune_mtime:
                return
            with open(self.tune_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            # YAML에서 max_steering_step=100을 넘겼는데 옛날 tune.json에 7로 저장되어 있는 경우 보호
            yaml_max_step = int(self.get_parameter("max_steering_step").value)
            for k, v in data.items():
                if k in self.params:
                    self.params[k] = v
            if yaml_max_step >= 50 and int(self.params.get("max_steering_step", 100)) <= 10:
                self.params["max_steering_step"] = yaml_max_step
            self.tune_mtime = st.st_mtime
            self.get_logger().info(f"tune loaded: {json.dumps(self.params)}")
        except Exception as e:
            self.get_logger().warn(f"tune reload failed: {e}")

    def on_traj(self, msg: LaneTrajectory):
        self.latest_traj = msg
        self.last_rx = self.get_clock().now()
        self._reload_tune()
        # 타이머를 기다리지 않고 경로 수신 즉시(0ms 딜레이) 제어 명령 계산 및 발행
        self._compute_and_publish(msg)

    def _compute_and_publish(self, msg: LaneTrajectory):
        p = self.params
        cmd = MotionCommand()
        now_sec = time.monotonic()
        dt = 0.033 if self.last_ctrl_time is None else float(np.clip(now_sec - self.last_ctrl_time, 0.005, 0.15))
        self.last_ctrl_time = now_sec

        if msg is None or not msg.valid:
            self.moving_since = None
            self._err_int *= 0.5
            self.pub.publish(cmd)
            return

        x = float(p["front_axle_offset_m"])
        raw_y_center = (msg.a * x + msg.b) * x + msg.c
        slope = 2.0 * msg.a * x + msg.b
        curv = 2.0 * msg.a

        # 코너 안쪽 바이어스 복원 (curv > 0 또는 slope > 0: 좌커브 → +방향(왼쪽) 오프셋 추가)
        turn_indicator = curv + 0.5 * slope
        if turn_indicator > 0.05:
            bias = float(p.get("inside_bias_m", 0.05)) * min(1.0, turn_indicator / 0.30)
        elif turn_indicator < -0.05:
            bias = -float(p.get("inside_bias_right_m", 0.0)) * min(1.0, (-turn_indicator) / 0.30)
        else:
            bias = 0.0

        y_err = raw_y_center + float(p["path_offset_m"]) + bias

        # 조향 I(적분) 제어 + 스마트 안티와인드업 (S자 변곡점 부호 반전 시 즉시 감쇠)
        i_gain = float(p.get("i_gain", 1.20))
        i_max_deg = float(p.get("i_max_deg", 12.0))
        if i_gain > 0.0:
            if (y_err * self._err_int) < 0.0:
                # 오차 방향이 반대로 바뀐 순간(S자 코너 전환 등) 누적된 적분값을 즉시 75% 털어냄
                self._err_int *= 0.25
            self._err_int += y_err * dt
            max_int = math.radians(i_max_deg) / max(i_gain, 1e-4)
            self._err_int = float(np.clip(self._err_int, -max_int, max_int))
        else:
            self._err_int = 0.0

        heading_err = math.atan(slope)
        cross_track = math.atan2(
            float(p["stanley_gain"]) * y_err,
            float(p["vehicle_speed_mps"]) + float(p["softening_speed_mps"]),
        )
        integral_term = i_gain * self._err_int

        steer_rad = (
            float(p["heading_gain"]) * heading_err
            + cross_track
            + float(p["curvature_gain"]) * curv
            + integral_term
        )

        max_rad = max(math.radians(float(p["max_steer_deg"])), 1e-3)
        max_step = int(p["max_steering_step"])
        target = float(p["steering_sign"]) * (steer_rad / max_rad) * max_step + float(p["steer_trim"])

        # 차선 이탈 방지 가드 (실선/점선에 과도하게 가까워졌을 때 끝까지 밀어줌)
        guard_r = float(p.get("lane_guard_m", 0.0))
        guard_l = float(p.get("lane_guard_left_m", 0.0))
        push_raw = float(p.get("lane_guard_push", 0.0))
        # max_step=100 인데 예전 7단계 시절 값(1~3)이 들어있으면 비율에 맞게 스케일링
        push = push_raw * (max_step / 7.0) if (max_step >= 50 and 0.0 < push_raw <= 7.0) else push_raw

        if guard_r > 0.0 and raw_y_center > guard_r and push > 0.0:
            # 차가 오른쪽 실선 쪽으로 밀려남(raw_y_center > guard_r) → 왼쪽(음수 조향)으로 강제 추가
            target += float(p["steering_sign"]) * push
        elif guard_l > 0.0 and raw_y_center < -guard_l and push > 0.0:
            # 차가 왼쪽 점선 쪽으로 밀려남 → 오른쪽(양수 조향)으로 강제 추가
            target -= float(p["steering_sign"]) * push

        target = float(np.clip(target, -max_step, max_step))

        rate = float(p.get("steer_rate", 0.0))
        if rate > 0.0:
            scale_rate = rate * (max_step / 7.0) if (max_step >= 50 and rate <= 10.0) else rate
            target = float(np.clip(target, self.prev_steer - scale_rate, self.prev_steer + scale_rate))
        self.prev_steer = target
        step = int(np.clip(round(target), -max_step, max_step))

        pwms = list(p["pwm_by_step"])
        idx = min(abs(step) * 7 // max(1, max_step), len(pwms) - 1)
        pwm = int(np.clip(pwms[idx], 0, 255))

        # 출발 및 급조향 시 정지 마찰 돌파 부스트
        boost = int(p.get("stall_boost_pwm", 0))
        if pwm > 0 and boost > pwm:
            if self.moving_since is None:
                self.moving_since = now_sec
                self.boost_until = now_sec + 0.4
            elif abs(step) >= (max_step * 5) // 7 and (now_sec - self.boost_until) > 0.4:
                self.boost_until = now_sec + 0.5
            if now_sec < self.boost_until:
                pwm = boost
        else:
            self.moving_since = None

        bal = int(p.get("motor_balance", 0))
        cmd.steering = step
        cmd.left_speed = int(np.clip(pwm - max(0, bal), 0, 255)) if pwm > 0 else 0
        cmd.right_speed = int(np.clip(pwm + min(0, bal), 0, 255)) if pwm > 0 else 0
        self.pub.publish(cmd)

    def tick(self):
        self._reload_tune()
        if self.last_rx is None:
            return
        age = (self.get_clock().now() - self.last_rx).nanoseconds * 1e-9
        if age > float(self.params["lane_timeout_sec"]):
            # 타임아웃 시 즉시 정지 명령 발행
            self.moving_since = None
            self._err_int = 0.0
            self.pub.publish(MotionCommand())


def main(args=None):
    rclpy.init(args=args)
    node = TunableController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
