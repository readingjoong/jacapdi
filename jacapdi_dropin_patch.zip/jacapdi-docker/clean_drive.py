#!/usr/bin/env python3
"""자캡디 정석 순수 추종(Pure Pursuit) + 실측 기하학(L=0.56m, 차폭=0.55m) 통합 주행 노드.

기존의 다단계 2차 함수 피팅(A~H) + 역외삽 구조를 완전히 걷어내고,
단 하나의 파일에서 /detections 를 받아 Pure Pursuit 기하학 공식 + 조향 적분(I) 제어로
즉시(0ms 딜레이) /topic_control_signal 과 /lane_trajectory 를 발행한다.

실측 차량 제원 반영:
- 축거(바퀴 중심 간 거리, L): 0.56m (56cm)
- 나무 포함 총 차폭: 0.55m (49cm + 좌우 3cm*2) → 85cm 차선 내 좌우 여유 각 15cm (0.12m 가드)
- 차량 앞코 ~ 카메라 렌즈: 0.544m (54.4cm), 렌즈 높이: 0.58m (58cm)
"""
import json
import math
import os
import sys
import time
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from interfaces_pkg.msg import DetectionArray, LaneTrajectory, MotionCommand

sys.path.insert(0, "/work")
try:
    import lane_from_lines as base
except ImportError:
    base = None

SOLID_CLASSES = {getattr(base, "SOLID_CLASS", "solid_line"), "solid_line", "lane_1"}
DASHED_CLASSES = {getattr(base, "DASHED_CLASS", "dashed_line"), "dashed_line", "lane_2_1"}

# 실측 차량 물리 상수
WHEELBASE_M = 0.56          # 바퀴 중심 간 거리 56cm
CAR_WIDTH_M = 0.55          # 차폭 49cm + 양쪽 나무 3cm*2 = 55cm
LANE_WIDTH_DEFAULT_M = 0.85 # 트랙 차선 폭 85cm


def _load_ipm(path: str) -> dict:
    if base is not None and hasattr(base, "load_ipm"):
        return base.load_ipm(path)
    f, h_cam, pitch_deg = 560.0, 0.607, 17.0
    w, h, cx, cy, top = 640, 480, 320.0, 240.0, 220
    if os.path.isfile(path):
        first_line = open(path, encoding="utf-8").readline()
        for tok in first_line.split():
            if tok.startswith("f="):
                f = float(tok[2:])
            elif tok.startswith("h="):
                h_cam = float(tok[2:])
            elif tok.startswith("pitch=") and "deg" in tok:
                pitch_deg = float(tok.split("=")[1].replace("deg", ""))
    th = math.radians(pitch_deg)
    u_grid, v_step = [], []
    for row in range(top, h):
        b = (row - cy) / f
        xd = math.cos(th) - math.sin(th) * b
        zd = -(math.sin(th) + math.cos(th) * b)
        t = h_cam / max(-zd, 1e-6)
        u_grid.append(float(t * xd))
        v_step.append(float(t / f))
    return {"w": w, "h": h, "cx": cx, "top": top, "u_grid": u_grid, "v_step": v_step}


def _fill_det(det, w: int, h: int, mask: np.ndarray) -> None:
    if base is not None and hasattr(base, "_fill"):
        base._fill(det, w, h, mask)
        return
    pts = getattr(getattr(det, "mask", None), "data", None)
    if pts and len(pts) >= 3:
        try:
            import cv2
            arr = np.array([[int(round(p.x)), int(round(p.y))] for p in pts], dtype=np.int32)
            cv2.fillPoly(mask, [arr], 1)
            return
        except Exception:
            xs = [int(round(p.x)) for p in pts]
            ys = [int(round(p.y)) for p in pts]
            y0, y1 = max(0, min(ys)), min(h - 1, max(ys))
            x0, x1 = max(0, min(xs)), min(w - 1, max(xs))
            mask[y0 : y1 + 1, x0 : x1 + 1] = 1


def _col_at(row_slice: np.ndarray):
    if base is not None and hasattr(base, "_col_at"):
        return base._col_at(row_slice)
    xs = np.flatnonzero(row_slice)
    if xs.size == 0:
        return None
    return float(np.median(xs))


class CleanPurePursuitNode(Node):
    def __init__(self):
        super().__init__("clean_drive_node")

        self.declare_parameter("ipm_yaml", "/work/ipm_c920.yaml")
        self.declare_parameter("tune_file", "/work/tune/tune.json")
        self.declare_parameter("lookahead_m", 0.90)  # 유효 전방 주시 거리 Ld

        self.ipm = _load_ipm(self.get_parameter("ipm_yaml").value)
        self.tune_file = str(self.get_parameter("tune_file").value)
        self.base_ld = float(self.get_parameter("lookahead_m").value)

        self.params = {
            "stanley_gain": 1.15,       # 슬라이더 호환: >1.0 이면 Pure Pursuit 반응 민감도 증가
            "heading_gain": 0.25,       # 근거리 차선 기울기 정렬 게인
            "i_gain": 1.20,             # 지속 커브 풀조향 도달용 적분(I) 게인
            "i_max_deg": 12.0,
            "max_steer_deg": 25.0,
            "max_steering_step": 100,
            "steering_sign": -1.0,
            "steer_trim": 0.0,
            "path_offset_m": 0.04,
            "inside_bias_m": 0.05,
            "inside_bias_right_m": 0.02,
            "motor_balance": 2,
            "stall_boost_pwm": 255,
            "lane_guard_m": 0.12,       # 차폭 55cm 기준 (여유 15cm 중 12cm 도달 시 즉시 가드)
            "lane_guard_left_m": 0.14,
            "lane_guard_push": 25,
            "lane_timeout_sec": 0.6,
            "pwm_by_step": [255, 255, 255, 255, 255, 255, 255, 255],
        }
        self.tune_mtime = 0.0
        self._last_tune_check = 0.0
        self._reload_tune(force=True)

        self.lane_width = LANE_WIDTH_DEFAULT_M
        self._ema_target = None
        self._ema_slope = 0.0
        self._err_int = 0.0
        self._last_valid_time = 0.0
        self._last_ctrl_time = None
        self._last_cmd = MotionCommand()
        self._frames = 0
        self._ok = 0

        qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            durability=DurabilityPolicy.VOLATILE,
            depth=1,
        )
        self.pub_cmd = self.create_publisher(MotionCommand, "/topic_control_signal", qos)
        self.pub_traj = self.create_publisher(LaneTrajectory, "/lane_trajectory", qos)
        self.pub_det = self.create_publisher(DetectionArray, "/lane_detections", qos)
        self.create_subscription(DetectionArray, "/detections", self.on_detections, qos)
        self.create_timer(2.0, self._log_status)

        self.get_logger().info(
            f"CleanPurePursuit started: wheelbase={WHEELBASE_M}m, car_width={CAR_WIDTH_M}m, Ld={self.base_ld}m"
        )

    def _reload_tune(self, force: bool = False):
        now = time.monotonic()
        if not force and (now - self._last_tune_check) < 0.25:
            return
        self._last_tune_check = now
        try:
            if not os.path.exists(self.tune_file):
                return
            st = os.stat(self.tune_file)
            if not force and st.st_mtime <= self.tune_mtime:
                return
            with open(self.tune_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            for k, v in data.items():
                if k in self.params:
                    self.params[k] = v
            if int(self.params.get("max_steering_step", 100)) <= 10:
                self.params["max_steering_step"] = 100
            self.tune_mtime = st.st_mtime
        except Exception:
            pass

    def _is_transverse(self, det) -> bool:
        w, h = self.ipm["w"], self.ipm["h"]
        top, cx = self.ipm["top"], self.ipm["cx"]
        u_grid, v_step = self.ipm["u_grid"], self.ipm["v_step"]
        m = np.zeros((h, w), dtype=np.uint8)
        _fill_det(det, w, h, m)
        us, vs = [], []
        for row in range(h - 1, top - 1, -6):
            col = _col_at(m[row])
            if col is not None:
                r = row - top
                us.append(float(u_grid[r]))
                vs.append(-(col - cx) * float(v_step[r]))
        if len(us) < 3:
            return False
        du = max(us) - min(us)
        dv = max(vs) - min(vs)
        return dv >= 0.15 and (du / max(dv, 1e-6)) < math.tan(math.radians(55.0))

    def _extract_uv(self, msg: DetectionArray):
        w, h = self.ipm["w"], self.ipm["h"]
        top, cx = self.ipm["top"], self.ipm["cx"]
        u_grid, v_step = self.ipm["u_grid"], self.ipm["v_step"]

        s_mask = np.zeros((h, w), dtype=np.uint8)
        d_mask = np.zeros((h, w), dtype=np.uint8)
        for det in msg.detections:
            if det.class_name in SOLID_CLASSES and det.score >= 0.30:
                if not self._is_transverse(det):
                    _fill_det(det, w, h, s_mask)
            elif det.class_name in DASHED_CLASSES and det.score >= 0.25:
                if not self._is_transverse(det):
                    _fill_det(det, w, h, d_mask)

        r_u, r_v, l_u, l_v = [], [], [], []
        for row in range(h - 1, top - 1, -4):
            r = row - top
            u = float(u_grid[r])
            if u > 1.55:  # 1.55m 너머의 먼 S자 변곡점 데이터는 원천 배제!
                continue
            sc = _col_at(s_mask[row])
            if sc is not None:
                v = -(sc - cx) * float(v_step[r])
                if -1.25 < v < 0.40:
                    r_u.append(u)
                    r_v.append(v)
            dc = _col_at(d_mask[row])
            if dc is not None:
                v = -(dc - cx) * float(v_step[r])
                if -0.35 < v < 1.35:
                    l_u.append(u)
                    l_v.append(v)
        return np.asarray(r_u), np.asarray(r_v), np.asarray(l_u), np.asarray(l_v)

    def _line_stats(self, u: np.ndarray, v: np.ndarray):
        """근거리 점들의 중앙값 위치(v_med)와 1차 기울기(m)를 추출한다."""
        if len(u) < 3:
            return None
        m, c = np.polyfit(u, v, 1)
        u_target = float(np.clip(1.05, float(np.min(u)), float(np.max(u))))
        v_target = float(m * u_target + c)
        return {"v": v_target, "m": float(m), "u_min": float(np.min(u)), "u_max": float(np.max(u)), "n": len(u)}

    def on_detections(self, msg: DetectionArray):
        self._frames += 1
        self._reload_tune()
        self.pub_det.publish(msg)

        now = time.monotonic()
        dt = 0.033 if self._last_ctrl_time is None else float(np.clip(now - self._last_ctrl_time, 0.005, 0.15))
        self._last_ctrl_time = now

        r_u, r_v, l_u, l_v = self._extract_uv(msg)
        r_stat = self._line_stats(r_u, r_v)
        l_stat = self._line_stats(l_u, l_v)

        if r_stat is not None and l_stat is not None:
            gap = l_stat["v"] - r_stat["v"]
            if 0.45 <= gap <= 1.15:
                self.lane_width = 0.90 * self.lane_width + 0.10 * float(np.clip(gap, 0.65, 1.00))
                # 실선 65% + 점선 35% 가중 평균으로 목표점(y_target) 산출
                y_r = r_stat["v"] + 0.5 * gap
                y_l = l_stat["v"] - 0.5 * gap
                y_raw = 0.65 * y_r + 0.35 * y_l
                m_raw = 0.65 * r_stat["m"] + 0.35 * l_stat["m"]
            else:
                perp = math.sqrt(1.0 + min(r_stat["m"] ** 2, 1.0))
                y_raw = r_stat["v"] + 0.5 * self.lane_width * perp
                m_raw = r_stat["m"]
        elif r_stat is not None:
            perp = math.sqrt(1.0 + min(r_stat["m"] ** 2, 1.0))
            y_raw = r_stat["v"] + 0.5 * self.lane_width * perp
            m_raw = r_stat["m"]
        elif l_stat is not None:
            perp = math.sqrt(1.0 + min(l_stat["m"] ** 2, 1.0))
            y_raw = l_stat["v"] - 0.5 * self.lane_width * perp
            m_raw = l_stat["m"]
        else:
            # 차선이 안 보일 때 0.8초까지는 직전 제어 유지, 이후 정지
            if (now - self._last_valid_time) <= 0.8 and self._ema_target is not None:
                self.pub_cmd.publish(self._last_cmd)
            else:
                self.pub_cmd.publish(MotionCommand())
            return

        # 저지연 EMA 필터
        if self._ema_target is None:
            self._ema_target = y_raw
            self._ema_slope = m_raw
        else:
            self._ema_target = 0.70 * y_raw + 0.30 * self._ema_target
            self._ema_slope = 0.70 * m_raw + 0.30 * self._ema_slope

        self._last_valid_time = now
        self._ok += 1

        p = self.params
        # 코너 인코스 바이어스 및 기본 오프셋 반영
        bias = float(p.get("inside_bias_m", 0.05)) if self._ema_slope > 0.08 else (
            -float(p.get("inside_bias_right_m", 0.02)) if self._ema_slope < -0.08 else 0.0
        )
        y_target = self._ema_target + float(p.get("path_offset_m", 0.04)) + bias

        # =====================================================================
        # 핵심: Pure Pursuit (순수 추종, 축거 L=0.56m) + 조향 I 제어
        # =====================================================================
        gain_scale = max(0.4, float(p.get("stanley_gain", 1.15)))
        ld = max(0.45, self.base_ld / math.sqrt(gain_scale))
        # 아크만 기하학 공식: delta = atan(2 * L * y_target / (Ld^2 + y_target^2))
        pp_rad = math.atan2(2.0 * WHEELBASE_M * y_target, ld * ld + y_target * y_target)
        heading_rad = float(p.get("heading_gain", 0.25)) * math.atan(self._ema_slope)

        # 적분(I) 제어 + S자 변곡점 부호 반전 시 즉시 감쇠
        i_gain = float(p.get("i_gain", 1.20))
        i_max_deg = float(p.get("i_max_deg", 12.0))
        if (y_target * self._err_int) < 0.0:
            self._err_int *= 0.25
        self._err_int += y_target * dt
        max_int = math.radians(i_max_deg) / max(i_gain, 1e-4)
        self._err_int = float(np.clip(self._err_int, -max_int, max_int))
        i_rad = i_gain * self._err_int

        steer_rad = pp_rad + heading_rad + i_rad
        max_rad = max(math.radians(float(p.get("max_steer_deg", 25.0))), 1e-3)
        max_step = int(p.get("max_steering_step", 100))
        target_step = float(p.get("steering_sign", -1.0)) * (steer_rad / max_rad) * max_step + float(p.get("steer_trim", 0.0))

        # 차폭 55cm 보호용 12cm 차선 가드
        guard_r = float(p.get("lane_guard_m", 0.12))
        guard_l = float(p.get("lane_guard_left_m", 0.14))
        push = float(p.get("lane_guard_push", 25.0))
        if max_step >= 50 and 0.0 < push <= 7.0:
            push *= (max_step / 7.0)
        if guard_r > 0.0 and self._ema_target > guard_r:
            target_step += float(p.get("steering_sign", -1.0)) * push
        elif guard_l > 0.0 and self._ema_target < -guard_l:
            target_step -= float(p.get("steering_sign", -1.0)) * push

        step = int(np.clip(round(target_step), -max_step, max_step))

        pwms = list(p.get("pwm_by_step", [255] * 8))
        idx = min(abs(step) * 7 // max(1, max_step), len(pwms) - 1)
        pwm = int(np.clip(pwms[idx], 0, 255))
        bal = int(p.get("motor_balance", 2))

        cmd = MotionCommand()
        cmd.steering = step
        cmd.left_speed = int(np.clip(pwm - max(0, bal), 0, 255)) if pwm > 0 else 0
        cmd.right_speed = int(np.clip(pwm + min(0, bal), 0, 255)) if pwm > 0 else 0
        self._last_cmd = cmd
        self.pub_cmd.publish(cmd)

        # frame_logger 및 path_viewer 호환용 궤적 토픽 발행
        traj = LaneTrajectory()
        traj.header = msg.header
        traj.valid = True
        traj.a = 0.0
        traj.b = float(self._ema_slope)
        traj.c = float(self._ema_target)
        traj.x_min_m = 0.84
        traj.x_max_m = 1.50
        traj.num_points = int((r_stat["n"] if r_stat else 0) + (l_stat["n"] if l_stat else 0))
        self.pub_traj.publish(traj)

    def _log_status(self):
        self.get_logger().info(
            f"frames={self._frames} ok={self._ok} y_target={self._ema_target or 0.0:+.3f}m "
            f"slope={self._ema_slope:+.3f} steer={self._last_cmd.steering:+d}%"
        )


def main(args=None):
    rclpy.init(args=args)
    node = CleanPurePursuitNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()

