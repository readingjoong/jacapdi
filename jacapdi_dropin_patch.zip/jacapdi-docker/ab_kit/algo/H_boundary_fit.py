#!/usr/bin/env python3
"""실험 H (업그레이드): 근거리 직선 중심 + 곡률 변곡점 가드 + 무지연 EMA 경로 생성 노드.

기존 E→F→G→H 다중 상속 구조의 고질적 문제 4가지를 근본 해결하면서도,
기존 실행 스크립트(start_ab.sh, car_prep.sh, car_go.sh) 및 ROS2 토픽과 100% 호환되는 드롭인 교체본.

핵심 개선점:
1. 고스트 홀드(F: 0.5초 경로 동결, G: 정지선 오탐 시 1.5초 동결) 완전 제거
   → S자 코너 변곡점 진입 시 과거 경로를 0.5~1.5초 동안 고집하던 현상 해결
2. 하단 첫 점(prev_r) 맹신 버그 수정 + 중앙값(Median/Huber) 기반 이상치 제거
   → 급좌회전 시 실선이 화면 중앙(v > 0.2m)으로 넘어와도 놓치지 않고 끝까지 추적
3. 0.84m 사각지대 역외삽(Backward Extrapolation) 왜곡 제거 + S자 변곡점 곡률 가드
   → 카메라가 실제로 보는 근거리(0.84~1.50m, 기준점 u_ref=1.00m)에서 직접 횡방향 오차와 기울기를 구하고,
     원거리 S자 반대 굴곡(a)이 현재 코너 탈출 전에 역조향을 유발하지 않도록 차단
"""
import math
import os
import sys
import time
import numpy as np

try:
    import yaml
except ImportError:
    yaml = None

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from interfaces_pkg.msg import DetectionArray, LaneTrajectory

sys.path.insert(0, "/work")
try:
    import lane_from_lines as base
except ImportError:
    base = None

SOLID_CLASS = getattr(base, "SOLID_CLASS", "solid_line")
DASHED_CLASS = getattr(base, "DASHED_CLASS", "dashed_line")
SOLID_CLASSES = {SOLID_CLASS, "solid_line", "lane_1"}
DASHED_CLASSES = {DASHED_CLASS, "dashed_line", "lane_2_1"}


def _load_ipm(path: str) -> dict:
    """우분투 컨테이너의 base.load_ipm(path)를 최우선 호출하고,
    오프라인/단독 실행 환경에서는 ipm_c920.yaml 의 카메라 파라미터(f=560, h=0.607, pitch=17deg)로 계산한다.
    """
    if base is not None and hasattr(base, "load_ipm"):
        return base.load_ipm(path)
    f, h_cam, pitch_deg = 560.0, 0.607, 17.0
    w, h, cx, cy, top = 640, 480, 320.0, 240.0, 220
    if os.path.isfile(path):
        first_line = open(path, encoding="utf-8").readline()
        for tok in first_line.split():
            if tok.startswith("f="):
                f = float(tok[2:])
            elif tok.startswith("h="):
                h_cam = float(tok[2:])
            elif tok.startswith("pitch=") and "deg" in tok:
                pitch_deg = float(tok.split("=")[1].replace("deg", ""))
    th = math.radians(pitch_deg)
    u_grid, v_step = [], []
    for row in range(top, h):
        b = (row - cy) / f
        xd = math.cos(th) - math.sin(th) * b
        zd = -(math.sin(th) + math.cos(th) * b)
        t = h_cam / max(-zd, 1e-6)
        u_grid.append(float(t * xd))
        v_step.append(float(t / f))
    return {"w": w, "h": h, "cx": cx, "top": top, "u_grid": u_grid, "v_step": v_step}


def _fill_det(det, w: int, h: int, mask: np.ndarray) -> None:
    """base._fill 호환: 세그멘테이션 폴리곤(또는 bbox)을 2D 마스크에 채운다."""
    if base is not None and hasattr(base, "_fill"):
        base._fill(det, w, h, mask)
        return
    pts = getattr(getattr(det, "mask", None), "data", None)
    if pts and len(pts) >= 3:
        try:
            import cv2
            arr = np.array([[int(round(p.x)), int(round(p.y))] for p in pts], dtype=np.int32)
            cv2.fillPoly(mask, [arr], 1)
            return
        except Exception:
            xs = [int(round(p.x)) for p in pts]
            ys = [int(round(p.y)) for p in pts]
            y0, y1 = max(0, min(ys)), min(h - 1, max(ys))
            x0, x1 = max(0, min(xs)), min(w - 1, max(xs))
            mask[y0 : y1 + 1, x0 : x1 + 1] = 1
            return
    bbox = getattr(det, "bbox", None)
    if bbox is not None:
        cx = float(bbox.center.position.x)
        cy = float(bbox.center.position.y)
        bw = float(bbox.size.x)
        bh = float(bbox.size.y)
        x0 = max(0, int(round(cx - bw * 0.5)))
        x1 = min(w - 1, int(round(cx + bw * 0.5)))
        y0 = max(0, int(round(cy - bh * 0.5)))
        y1 = min(h - 1, int(round(cy + bh * 0.5)))
        if x1 >= x0 and y1 >= y0:
            mask[y0 : y1 + 1, x0 : x1 + 1] = 1


def _col_at(row_slice: np.ndarray):
    if base is not None and hasattr(base, "_col_at"):
        return base._col_at(row_slice)
    xs = np.flatnonzero(row_slice)
    if xs.size == 0:
        return None
    return float(np.median(xs))


def _robust_line_fit(u: np.ndarray, v: np.ndarray, u_ref: float):
    """u_ref 기준점 중심으로 강건한 1차 직선 v(u) = m * (u - u_ref) + v_ref 피팅.
    노이즈 점이 섞여 있어도 잔차(Residual) 기반으로 이상치를 걸러내고 정확한 기울기와 절편을 구한다.
    """
    du = u - u_ref
    if len(u) < 2:
        return 0.0, float(v[0]) if len(v) else 0.0, 0.0
    m, v_ref = np.polyfit(du, v, 1)
    if len(u) >= 5:
        res = np.abs((m * du + v_ref) - v)
        med = float(np.median(res))
        inliers = res <= max(0.06, 2.5 * med)
        if int(np.sum(inliers)) >= 3:
            m, v_ref = np.polyfit(du[inliers], v[inliers], 1)
            res = np.abs((m * du[inliers] + v_ref) - v[inliers])
    err = float(np.sqrt(np.mean(res ** 2))) if len(u) >= 5 else 0.0
    return float(m), float(v_ref), err


class LinePathNodeH(Node):
    def __init__(self):
        super().__init__("line_path_node")

        # start_ab.sh 및 기존 A~H 설정과 100% 호환되는 파라미터 선언
        self.declare_parameter("ipm_yaml", "/work/ipm_c920.yaml")
        self.declare_parameter("mode", "solid_follow")
        self.declare_parameter("lane_width_m", 0.85)
        self.declare_parameter("online_width", True)
        self.declare_parameter("min_rows", 0.06)
        self.declare_parameter("max_gap", 0.40)
        self.declare_parameter("hold_last_sec", 1.0)
        self.declare_parameter("solid_min_score", 0.30)
        self.declare_parameter("dashed_min_score", 0.25)
        self.declare_parameter("transverse_deg", 55.0)
        self.declare_parameter("near_range_m", 0.75)     # 카메라 하단(0.84m)부터 +0.75m(1.59m)까지 근거리 집중
        self.declare_parameter("lookahead_u_m", 1.00)    # 사각지대 역외삽을 없애는 실측 기준 거리(1.00m)
        self.declare_parameter("ctrl_eval_x_m", 0.10)    # 제어기(tunable_controller)가 대입하는 x 좌표
        self.declare_parameter("dash_join_gap_m", 0.60)
        self.declare_parameter("width_tol_m", 0.28)
        self.declare_parameter("ema_alpha", 0.65)        # 경로 끊김/튐 완화용 저지연 EMA 계수

        self.ipm = _load_ipm(self.get_parameter("ipm_yaml").value)
        self.lane_width = float(self.get_parameter("lane_width_m").value)
        self.online_width = bool(self.get_parameter("online_width").value)
        self.hold_last_sec = float(self.get_parameter("hold_last_sec").value)
        self.solid_min = float(self.get_parameter("solid_min_score").value)
        self.dashed_min = float(self.get_parameter("dashed_min_score").value)
        self.tan_min = math.tan(math.radians(float(self.get_parameter("transverse_deg").value)))
        self.near_range = float(self.get_parameter("near_range_m").value)
        self.u_ref = float(self.get_parameter("lookahead_u_m").value)
        self.x_eval = float(self.get_parameter("ctrl_eval_x_m").value)
        self.dash_join_gap = float(self.get_parameter("dash_join_gap_m").value)
        self.width_tol = float(self.get_parameter("width_tol_m").value)
        self.ema_alpha = float(self.get_parameter("ema_alpha").value)

        # 상태 및 car_prep.sh 호환 통계 변수
        self._last_traj = None
        self._last_time = 0.0
        self._ema_abc = None
        self._frames = 0
        self._ok = 0
        self._both = 0
        self._one_side = 0
        self._search = 0
        self._held = 0
        self._transverse_dropped = 0
        self._dash_joined = 0
        self._last_mode = ""

        qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            durability=DurabilityPolicy.VOLATILE,
            depth=1,
        )
        self.pub = self.create_publisher(LaneTrajectory, "/lane_trajectory", qos)
        self.det_pub = self.create_publisher(DetectionArray, "/lane_detections", qos)
        self.create_subscription(DetectionArray, "/detections", self.cb, qos)
        self.create_timer(2.0, self.log_status)

        self.get_logger().info(
            f"algo H (upgraded): solid>={self.solid_min:.2f} dashed>={self.dashed_min:.2f}, "
            f"near_range={self.near_range:.2f}m, u_ref={self.u_ref:.2f}m, ema={self.ema_alpha:.2f}"
        )

    def _is_transverse(self, det) -> bool:
        """정지선이나 트랙 매트 가로 이음새처럼 가로로 누운 박스를 제거한다."""
        w, h = self.ipm["w"], self.ipm["h"]
        top, cx = self.ipm["top"], self.ipm["cx"]
        u_grid, v_step = self.ipm["u_grid"], self.ipm["v_step"]
        m = np.zeros((h, w), dtype=np.uint8)
        _fill_det(det, w, h, m)
        us, vs = [], []
        for row in range(h - 1, top - 1, -6):
            col = _col_at(m[row])
            if col is not None:
                r = row - top
                us.append(float(u_grid[r]))
                vs.append(-(col - cx) * float(v_step[r]))
        if len(us) < 3:
            return False
        du = max(us) - min(us)
        dv = max(vs) - min(vs)
        if dv < 0.15:
            return False
        if du / max(dv, 1e-6) < self.tan_min:
            self._transverse_dropped += 1
            return True
        return False

    def _filter_track_continuity(self, u_list: list, v_list: list, v_min: float, v_max: float):
        """하단 첫 점(prev_r) 하나에 의존하던 취약한 방식을 버리고,
        전체 유효 범위(v_min ~ v_max) 안의 점들 중 주 추세선에서 벗어난 이상치만 제거한다.
        """
        u_arr = np.asarray(u_list, dtype=float)
        v_arr = np.asarray(v_list, dtype=float)
        valid = (v_arr > v_min) & (v_arr < v_max)
        u_arr, v_arr = u_arr[valid], v_arr[valid]
        if len(u_arr) < 4:
            return u_arr, v_arr
        # 1차 추세선 대비 18cm 이상 튄 바닥 반사광/이음새 점 제거
        m, c = np.polyfit(u_arr, v_arr, 1)
        res = np.abs((m * u_arr + c) - v_arr)
        keep = res < max(0.18, 2.5 * float(np.median(res)))
        if int(np.sum(keep)) >= 4:
            u_arr, v_arr = u_arr[keep], v_arr[keep]
        return u_arr, v_arr

    def _extract_boundaries(self, msg: DetectionArray):
        w, h = self.ipm["w"], self.ipm["h"]
        top, cx = self.ipm["top"], self.ipm["cx"]
        u_grid, v_step = self.ipm["u_grid"], self.ipm["v_step"]

        s_mask = np.zeros((h, w), dtype=np.uint8)
        dash_dets = []
        for det in msg.detections:
            if det.class_name in SOLID_CLASSES and det.score >= self.solid_min:
                if not self._is_transverse(det):
                    _fill_det(det, w, h, s_mask)
            elif det.class_name in DASHED_CLASSES and det.score >= self.dashed_min:
                if not self._is_transverse(det):
                    dash_dets.append(det)
            # stop_line 은 완전히 무시 (트랙 매트 이음새 오탐으로 인한 G_cross_hold 방지)

        # 오른쪽 실선 추출: 급좌회전 시 차가 실선 가까이 붙으면 실선 v가 +0.35m까지 올라오므로 상한을 0.40m로 확대
        r_u, r_v = [], []
        for row in range(h - 1, top - 1, -4):
            col = _col_at(s_mask[row])
            if col is not None:
                r = row - top
                u = float(u_grid[r])
                v = -(col - cx) * float(v_step[r])
                r_u.append(u)
                r_v.append(v)
        r_u_arr, r_v_arr = self._filter_track_continuity(r_u, r_v, v_min=-1.25, v_max=0.40)

        # 왼쪽 점선 조각 추출 및 연결
        segs = []
        for det in dash_dets:
            dm = np.zeros((h, w), dtype=np.uint8)
            _fill_det(det, w, h, dm)
            su, sv = [], []
            for row in range(h - 1, top - 1, -4):
                col = _col_at(dm[row])
                if col is not None:
                    r = row - top
                    u = float(u_grid[r])
                    v = -(col - cx) * float(v_step[r])
                    if -0.35 < v < 1.35:
                        su.append(u)
                        sv.append(v)
            if len(su) >= 2:
                segs.append((min(su), max(su), su, sv))

        segs.sort(key=lambda s: s[0])
        l_u, l_v = [], []
        for u0, u1, su, sv in segs:
            if not l_u:
                l_u.extend(su)
                l_v.extend(sv)
            else:
                du = u0 - l_u[-1]
                dv = abs(sv[0] - l_v[-1])
                if -0.15 <= du <= self.dash_join_gap and dv < 0.25 + 0.35 * max(0.0, du):
                    l_u.extend(su)
                    l_v.extend(sv)
                    self._dash_joined += 1
        l_u_arr, l_v_arr = self._filter_track_continuity(l_u, l_v, v_min=-0.35, v_max=1.35)
        return r_u_arr, r_v_arr, l_u_arr, l_v_arr

    def _pack_for_controller(self, a_curv: float, m_near: float, y_ref: float):
        """제어기(tunable_controller)가 x = self.x_eval (0.10m)에서 식을 계산할 때,
        역외삽 오차 없이 정확히 근거리 실측 기준점(u_ref=1.00m)의
        y_center = y_ref, slope = m_near, curv = 2*a_curv 가 나오도록 (a, b, c)를 역산해 패킹한다.
        """
        x0 = self.x_eval
        a = float(a_curv)
        b = float(m_near) - 2.0 * a * x0
        c = float(y_ref) - b * x0 - a * x0 * x0
        return a, b, c

    def _compute_edge_metrics(self, u: np.ndarray, v: np.ndarray):
        """경계선 점들(u, v)에서 근거리(near) 기울기/위치와 중거리 곡률(a)을 분리 계산."""
        if len(u) < 4:
            return None
        u_min = float(np.min(u))
        # 1. 근거리 구간(u_min ~ u_min + near_range): 조향의 핵심 기준 (직선 피팅으로 S자 왜곡 원천 차단)
        near_mask = u <= (u_min + self.near_range)
        u_near = u[near_mask] if int(np.sum(near_mask)) >= 4 else u[: max(4, len(u) // 2)]
        v_near = v[near_mask] if int(np.sum(near_mask)) >= 4 else v[: max(4, len(v) // 2)]

        u_ref_actual = float(np.clip(self.u_ref, float(np.min(u_near)), float(np.max(u_near))))
        m_near, v_ref, err = _robust_line_fit(u_near, v_near, u_ref_actual)
        # u_ref(1.00m)와의 미세 거리 차이를 근거리 기울기로 보정 (최대 ±10cm 이내 내삽)
        v_at_ref = v_ref + m_near * (self.u_ref - u_ref_actual)

        # 2. 중거리 곡률(a) 추정 (0.84m ~ 1.75m 구간, 과도한 2차항 폭주 방지 클램프)
        mid_mask = u <= (u_min + 0.95)
        u_mid = u[mid_mask] if int(np.sum(mid_mask)) >= 6 else u
        v_mid = v[mid_mask] if int(np.sum(mid_mask)) >= 6 else v
        a_curv = 0.0
        if len(u_mid) >= 6 and (float(np.max(u_mid)) - float(np.min(u_mid))) >= 0.30:
            poly = np.polyfit(u_mid - self.u_ref, v_mid, 2)
            a_curv = float(np.clip(poly[0], -0.25, 0.25))

        return {
            "a": a_curv,
            "m": m_near,
            "v_ref": v_at_ref,
            "err": err,
            "n": len(u),
            "u_min": float(np.min(u)),
            "u_max": float(np.max(u)),
        }

    def _offset_single_boundary(self, edge: dict, offset_sign: float):
        """한쪽 차선만 보일 때 법선(Normal) 방향으로 반폭(0.5 * lane_width)만큼 평행이동."""
        half_w = 0.5 * self.lane_width
        m = edge["m"]
        # 차선이 기울어져 있을 때 수직 거리 half_w 를 확보하기 위한 y방향 이동량: half_w * sqrt(1 + m^2)
        perp_scale = math.sqrt(1.0 + min(m * m, 1.0))
        y_ref = edge["v_ref"] + offset_sign * half_w * perp_scale
        return edge["a"], m, y_ref

    def cb(self, msg: DetectionArray):
        self._frames += 1
        self.det_pub.publish(msg)

        r_u, r_v, l_u, l_v = self._extract_boundaries(msg)
        r_edge = self._compute_edge_metrics(r_u, r_v)
        l_edge = self._compute_edge_metrics(l_u, l_v)

        if r_edge is not None and l_edge is not None:
            gap = l_edge["v_ref"] - r_edge["v_ref"]
            if abs(gap - self.lane_width) <= self.width_tol and gap > 0.35:
                if self.online_width:
                    self.lane_width = 0.90 * self.lane_width + 0.10 * float(np.clip(gap, 0.65, 1.05))
                # 양쪽 차선이 모두 정상일 때: 오른쪽 실선에 65%, 왼쪽 점선에 35% 가중치 부여 (실선 이탈 방지)
                w_r, w_l = 0.65, 0.35
                a_raw = w_r * r_edge["a"] + w_l * l_edge["a"]
                m_raw = w_r * r_edge["m"] + w_l * l_edge["m"]
                y_r_center = r_edge["v_ref"] + 0.5 * gap
                y_l_center = l_edge["v_ref"] - 0.5 * gap
                y_raw = w_r * y_r_center + w_l * y_l_center
                err = 0.5 * (r_edge["err"] + l_edge["err"])
                n_pts = r_edge["n"] + l_edge["n"]
                u0 = min(r_edge["u_min"], l_edge["u_min"])
                u1 = max(r_edge["u_max"], l_edge["u_max"])
                self._both += 1
                self._last_mode = "both_near"
            else:
                # 폭이 비정상(교차로/점선 오탐)이면 더 신뢰도가 높은 실선 기준 추종
                a_raw, m_raw, y_raw = self._offset_single_boundary(r_edge, +1.0)
                err, n_pts = r_edge["err"], r_edge["n"]
                u0, u1 = r_edge["u_min"], r_edge["u_max"]
                self._one_side += 1
                self._last_mode = "solid_width_guard"
        elif r_edge is not None:
            a_raw, m_raw, y_raw = self._offset_single_boundary(r_edge, +1.0)
            err, n_pts = r_edge["err"], r_edge["n"]
            u0, u1 = r_edge["u_min"], r_edge["u_max"]
            self._one_side += 1
            self._last_mode = "solid_only"
        elif l_edge is not None:
            a_raw, m_raw, y_raw = self._offset_single_boundary(l_edge, -1.0)
            err, n_pts = l_edge["err"], l_edge["n"]
            u0, u1 = l_edge["u_min"], l_edge["u_max"]
            self._one_side += 1
            self._last_mode = "dashed_only"
        else:
            self._publish_hold_or_invalid(msg)
            return

        # 핵심 방어 로직: S자 코너 변곡점 역조향 가드 (Inflection Guard)
        # 현재 근거리에서 차가 한쪽으로 크게 쏠려 코너를 돌고 있는데(y_raw와 m_raw가 같은 방향),
        # 멀리 있는 S자 다음 코너 때문에 곡률(a_raw) 부호가 반대로 뒤집히면 a_raw를 0으로 차단한다!
        near_demand = y_raw + 0.35 * m_raw
        if abs(near_demand) > 0.06 and (a_raw * near_demand) < 0.0:
            a_raw = 0.0
            self._last_mode += "+inflect_guard"

        a_pack, b_pack, c_pack = self._pack_for_controller(a_raw, m_raw, y_raw)

        # 고스트 동결(0.5초 멈춤) 대신 부드럽고 즉각적인 EMA 필터 적용
        if self._ema_abc is None:
            self._ema_abc = (a_pack, b_pack, c_pack)
        else:
            alpha = self.ema_alpha
            pa, pb, pc = self._ema_abc
            self._ema_abc = (
                alpha * a_pack + (1.0 - alpha) * pa,
                alpha * b_pack + (1.0 - alpha) * pb,
                alpha * c_pack + (1.0 - alpha) * pc,
            )

        out = LaneTrajectory()
        out.header = msg.header
        out.valid = True
        out.a = float(self._ema_abc[0])
        out.b = float(self._ema_abc[1])
        out.c = float(self._ema_abc[2])
        out.x_min_m = float(u0)
        out.x_max_m = float(u1)
        out.fit_error_m = float(err)
        out.num_points = int(n_pts)

        self._last_traj = out
        self._last_time = time.monotonic()
        self._ok += 1
        self.pub.publish(out)

    def _publish_hold_or_invalid(self, msg: DetectionArray):
        now = time.monotonic()
        out = LaneTrajectory()
        out.header = msg.header
        if self._last_traj is not None and (now - self._last_time) <= self.hold_last_sec:
            out.valid = True
            out.a = self._last_traj.a
            out.b = self._last_traj.b
            out.c = self._last_traj.c
            out.x_min_m = self._last_traj.x_min_m
            out.x_max_m = self._last_traj.x_max_m
            out.fit_error_m = self._last_traj.fit_error_m
            out.num_points = self._last_traj.num_points
            self._held += 1
            self._last_mode = "hold"
        else:
            out.valid = False
            self._ema_abc = None
            self._last_mode = "invalid"
        self.pub.publish(out)

    def log_status(self):
        # car_prep.sh 가 검사하는 "frames=" 문자열 포맷 100% 유지
        self.get_logger().info(
            f"frames={self._frames} ok={self._ok} "
            f"(both {self._both}, one_side {self._one_side}, search {self._search}) "
            f"held={self._held} transverse_dropped={self._transverse_dropped} "
            f"dash_joined={self._dash_joined} last={self._last_mode}"
        )


def main(args=None):
    rclpy.init(args=args)
    node = LinePathNodeH()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
