#!/usr/bin/env bash
# Pure Pursuit 정석 단일 노드(clean_drive.py)로 주행 (car_prep.sh 상태에서 바로 실행 가능!)
# 사용법: ~/jacapdi-docker/clean_go.sh [초]     (Ctrl+C = 즉시 정지 및 car_prep 상태 자동 복구)
source "$(dirname "$0")/car_common.sh"
SEC="${1:-$DRIVE_SEC}"
docker ps -q -f name="$C" | grep -q . || die "컨테이너 없음. 먼저 ~/jacapdi-docker/car_prep.sh"

RUN=$(cat /tmp/car_run_dir 2>/dev/null)
OUT=""
if [ "${LOG:-1}" = 1 ] && [ -n "$RUN" ]; then
  OUT="$RUN/clean_drive_$(date +%H%M%S)"; mkdir -p "$OUT"
  docker exec -d "$C" bash -ic "python3 ~/jacapdi-docker/frame_logger.py $OUT 10 ${RAW:-0} > $OUT/logger.log 2>&1"
  say "10 Hz 기록 시작(Pure Pursuit): $OUT"
fi

stop_logger() {
  [ -n "$OUT" ] || return 0
  docker exec "$C" bash -c 'pkill -INT -f frame_logger.py' >/dev/null 2>&1
  sleep 1.0
  say "기록: $(ls "$OUT/frames" 2>/dev/null | wc -l)장 -> $OUT (frames.csv)"
}

stop_now() {
  trap - INT TERM
  echo
  warn "정지 중 (Pure Pursuit 종료 및 prep 상태 복구)..."
  send_stop
  docker exec "$C" bash -c 'pkill -9 -f clean_drive.py; kill -CONT $(pgrep -f "ab_kit/algo/|tunable_controller.py") 2>/dev/null' >/dev/null 2>&1 || true
  stop_logger
  yolo_on false && say "YOLO 꺼 둠 (배터리 절약) - 다시 ./clean_go.sh 또는 ./car_go.sh 바로 실행 가능!"
  [ -n "$RUN" ] && grep "FAULT:" "$RUN/board.log" 2>/dev/null | tail -2
  exit 0
}
trap stop_now INT TERM

# 1. 기존 H_boundary_fit / tunable_controller 일시 정지(SIGSTOP) 후 clean_drive.py 기동
docker exec "$C" bash -c '
  kill -STOP $(pgrep -f "ab_kit/algo/|tunable_controller.py") 2>/dev/null || true
  pkill -9 -f clean_drive.py 2>/dev/null || true
' >/dev/null 2>&1
docker exec -d "$C" bash -ic "python3 /work/clean_drive.py --ros-args -p ipm_yaml:=/work/ipm_c920.yaml -p tune_file:=/work/tune/tune.json > ${RUN:-/tmp}/clean_drive.log 2>&1"
sleep 0.3

# 2. 출발 직전에 YOLO 깨우기
yolo_on true || { trap - INT TERM; warn "YOLO 켜기 실패. 출발하지 않음"; stop_now; exit 1; }

say "출발 [Pure Pursuit 정석 모드, L=0.56m]: ${SEC}초  (Ctrl+C = 즉시 정지)"
docker exec "$C" bash -c "DRIVE_SEC=$SEC ~/jacapdi-docker/timed_drive.sh" 2>&1 | grep -vE "RCLError|rcl_shutdown|Traceback|File |^\s|KeyboardInterrupt|ros2run" &
wait $!
stop_now

