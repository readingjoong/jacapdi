#!/usr/bin/env bash
set -e
TARGET="$HOME/jacapdi-docker"
ARD_DIR="$HOME/jacapdi-live-car-2026-09-24/arduino/driving_team_cal_1010f"

[ -f "$TARGET/ab_kit/algo/H_boundary_fit.py.bak" ] && cp -f "$TARGET/ab_kit/algo/H_boundary_fit.py.bak" "$TARGET/ab_kit/algo/H_boundary_fit.py"
[ -f "$TARGET/tunable_controller.py.bak" ] && cp -f "$TARGET/tunable_controller.py.bak" "$TARGET/tunable_controller.py"
[ -f "$TARGET/tune_gui.py.bak" ] && cp -f "$TARGET/tune_gui.py.bak" "$TARGET/tune_gui.py"
[ -f "$TARGET/tune/tune.json.bak" ] && cp -f "$TARGET/tune/tune.json.bak" "$TARGET/tune/tune.json"
rm -f "$TARGET/clean_drive.py" "$TARGET/clean_go.sh"

if [ -f "$ARD_DIR/driving_team_cal_1010f.ino.bak" ]; then
  cp -f "$ARD_DIR/driving_team_cal_1010f.ino.bak" "$ARD_DIR/driving_team_cal_1010f.ino"
fi
if [ -f "$ARD_DIR/driving_team_cal_1010f.ino.hex.bak" ]; then
  cp -f "$ARD_DIR/driving_team_cal_1010f.ino.hex.bak" "$ARD_DIR/driving_team_cal_1010f.ino.hex"
  "$TARGET/car_flash.sh" || true
fi

echo "원래 파일(*.bak)로 100% 롤백 완료!"
